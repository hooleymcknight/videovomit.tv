'use client';
import LiteYouTubeEmbed from 'react-lite-youtube-embed';
import 'react-lite-youtube-embed/dist/LiteYouTubeEmbed.css';
import EmblaCarousel from './Embla/EmblaCarousel';

const OPTIONS = { containScroll: false }

export default function YtCarousel (props) {

    return (
        <div className="flex flex-wrap gap-[20px]">
            {
                props.items && props.items.length ?
                    <EmblaCarousel slides={props.items} />
                :
                null
            }
        </div>
    );
}